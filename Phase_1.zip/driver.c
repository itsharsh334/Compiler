/*
GROUP NUMBER: 5
MEMBERS:
    1. HRISHIKESH HARSH (2020A7PS0313P)
    2. HARSH PRIYADARSHI (2020A7PS0110P)
    3. ANTRIKSH SHARMA (2020A7PS1691P)
    4. KAUSTAB CHOUDHURY (2020A7PS0013P)
    5. SHASHANK SHREEDHAR BHATT (2020A7PS0078P)
*/

#include "parser.c"
#include <time.h>

void emptyBuffer(char *buffer)
{
    /* Empties the buffer */
    for (int i = 0; i < BUFFER_SIZE; i++)
        buffer[i] = '\0';
    return;
}

void callLexer(char *test_file_name)
{
    /*
    - The first 4 lines of this function are to reset everything to the initial state in case callParser() was called before this function.
    - Please DO NOT change any of these lines.
    */
    lineNum = 1;
    EOF_Flag = 0;
    emptyBuffer(buffer_1);
    emptyBuffer(buffer_2);
    emptyBuffer(selected_buffer);

    buffer_1[BUFFER_SIZE] = '\0';
    buffer_2[BUFFER_SIZE] = '\0';
    selected_buffer[BUFFER_SIZE] = '\0';

    /*
    -   The following lines are to initialise the hash table for the lexer.
    -   The hash table is populated with the keywords
    */
    hash_linked_list *hash_table = construct_hash_table_lexer();
    hash_table = populate_hash_table_lexer(hash_table);
    // print_hash_table(hash_table);

    FILE *fp = fopen(test_file_name, "r");
    if (fp == NULL)
    {
        printf("Error opening file\n");
        exit(1);
    }

    fillBuffers(fp);

    int begin = 0;
    int forward = 0;
    while (EOF_Flag == 0)
    {
        token_info token8 = getNextToken(fp, hash_table, &begin, &forward);
        if (token8 == NULL)
            continue;

        if (token8->type == ERROR_ID)
        {
            // printf("Error: \"%s\" Size exceeds %d | Line: %d\n", big_identifier, LEXEME_SIZE, lineNum);
            // token8=tokenise();
            // token8 = (token_info)malloc(sizeof(struct token_info));
            // token8->type = ERROR;
            // token8->lineNum = lineNum;
            // printf("ERROR: %s | line: %d | Type: %d\n", big_identifier, token8->lineNum, token8->type);
            free(big_identifier);
        }
        else if (token8->type == ERROR)
        {
            // do nothing
            // printf("ERROR: %s | line: %d ", token8->content.identifier, token8->lineNum);
        }
        else if (EOF_Flag == 0)
            printToken(token8);
        // //         {
        //           if (lexerError != 1)
        //             printToken(token8);
        //           else
        //             lexerError = 0;
        // //         }
        bufferSwitch(&begin, &forward, fp, 1);
    }
    fclose(fp);
    return;
}

void callParser(char *test_file_name, char *tree_out_name)
{
    /*
    - The first 4 lines of this function are to reset everything to the initial state in case callLexer() was called before this function.
    - Please DO NOT change any of these lines.
    */
    lineNum = 1;
    EOF_Flag = 0;
    emptyBuffer(buffer_1);
    emptyBuffer(buffer_2);
    emptyBuffer(selected_buffer);

    buffer_1[BUFFER_SIZE] = '\0';
    buffer_2[BUFFER_SIZE] = '\0';
    selected_buffer[BUFFER_SIZE] = '\0';

    /*
    -   The following lines are to initialise the hash table for the parser.
    -   The hash table is populated with the terminals and non-terminals
    */

    /*
    Brief description of the variables used here on:
     - grammar: The grammar of the language
     - reversedGrammar: The reversed grammar of the language
     - epsilon_set: The set of non-terminals that can derive epsilon
     - set_first: The first set of all non-terminals
     - rule_wise_first: The first set of all rules
     - set_follow: The follow set of all non-terminals
     - parse_table: The parse table of the language
     - parse_tree: The parse tree of the input source code
    */

    /*
    -   The following lines populate, construct and get ready all the above variables necessary for the parser.
    -   Kindly DO NOT tamper with any of these lines.
    -   If you wish to ever print any of the above variables, you can do so by uncommenting the respective print functions.
    -   Please note that we were not aware that comments could exceed BUFFER_SIZE. If it does, the lexer output would be erroneous.
    -   Hence take care to not exceed BUFFER_SIZE in your comments.
    */
    alpha_list *hash_table_parser = construct_hash_table_parser();
    hash_table_parser = populate_hash_table_parser(hash_table_parser);
    // print_alpha_list(hash_table_parser);

    FILE *fp_2 = fopen("grammar.txt", "r");

    if (fp_2 == NULL)
        printf("Error opening grammar.txt file!\n");

    grammar = malloc(NUM_RULES * sizeof(alpha_node));
    grammar = createGrammarBase(fp_2, hash_table_parser);
    // printf("\n check 1");
    if (grammar == NULL)
        printf("Unable to create grammar base!\n");

    // printGrammar(grammar, NUM_RULES);

    epsilon_set = getEpsilonNonTerminals(grammar, NUM_RULES);

    reversedGrammar = malloc(NUM_RULES * sizeof(alpha_node));
    reversedGrammar = reverseGrammar(grammar);

    // printf("\n[Reversed]");
    // printGrammar(reversedGrammar, NUM_RULES);

    set_first = (Set **)malloc(NUM_NON_TERMINALS * sizeof(Set *));

    for (int i = NUM_NON_TERMINALS - 1; i >= 0; i--)
    {
        set_first[i] = (Set *)malloc(sizeof(Set));
        set_first[i]->array = malloc(NUM_TERMINALS * sizeof(int));
        set_first[i]->array = getFirstSet(grammar, i);
        set_first[i]->size = getSize(set_first[i]->array, NUM_TERMINALS);
    }

    // displaySet(set_first, NUM_NON_TERMINALS, 0);

    rule_wise_first = (Set **)malloc(NUM_RULES * sizeof(Set *));

    for (int i = 0; i < NUM_RULES; i++)
    {
        rule_wise_first[i] = (Set *)malloc(sizeof(Set));
        rule_wise_first[i]->array = (int *)malloc(NUM_TERMINALS * sizeof(int));
        rule_wise_first[i]->array = getFirstSetForRule(grammar[i]);
        rule_wise_first[i]->size = getSize(rule_wise_first[i]->array, NUM_TERMINALS);
    }

    // displayRuleWiseFirstSet(rule_wise_first, NUM_RULES);

    set_follow = (Set **)malloc(NUM_NON_TERMINALS * sizeof(Set *));
    set_follow[0] = (Set *)malloc(sizeof(Set));
    set_follow[0]->array = malloc(NUM_TERMINALS * sizeof(int));
    set_follow[0]->array[DOLLAR] = 1;
    set_follow[0]->size = 1;

    for (int i = 1; i < NUM_NON_TERMINALS; i++)
    {
        set_follow[i] = (Set *)malloc(sizeof(Set));
        set_follow[i]->array = malloc(NUM_TERMINALS * sizeof(int));
        set_follow[i]->array = getFollowSet(grammar, i);
        set_follow[i]->size = getSize(set_follow[i]->array, NUM_TERMINALS);
    }

    // displaySet(set_follow, NUM_NON_TERMINALS, 1);

    int **parseTable = (int **)malloc(NUM_NON_TERMINALS * sizeof(int *));

    for (int i = 0; i < NUM_NON_TERMINALS; i++)
    {
        parseTable[i] = (int *)malloc(NUM_TERMINALS * sizeof(int));
    }
    createParseTable(rule_wise_first, set_follow, grammar, parseTable);

    // printParseTable(parseTable, grammar);

    fclose(fp_2);
    /*
    Daily Thoughts of a Programmer:
    - I wonder if I will ever be able to write a code without any bugs
    - I wish the debugger could speak to me better
    - We really did spend 4 HOURS debugging the Follow Set function
    - I really wonder how I'll draw the equivalence between the token_info and the alpha_node
    - Parsing is really hard
    - Parse_Tree..... Ahhhh... Stress...!
    - Man, the transition was not smooth at all
    - Struggling a bit right now
    - Teammates are really helpful
    - Should I get a coffee? Or Sleep?
    - I really need to get some sleep
    - Man, I made such a stupid blunder in the First/Follow concept
    - It was terrible, especially after all the pains I took to get them running
    */

    parseTree parse_tree = parseInputSourceCode(test_file_name, parseTable, grammar, reversedGrammar);
    
    if(syntax_error == 1)
    {
        printf("\n[Please note that the error message of the same line may be repeated multiple times]\n");
        printf("[This happens as the Parser tries to recover from the error]\n\n");
    }

    printParseTree(parse_tree, tree_out_name);

    printf("[Parse Tree Generated \u2713]\n");

    return;
}

void printMenu()
{
    printf("------------------------------------------------------------\n");
    printf("[0 : Exit]\n");
    printf("[1 : Remove Comments]\n");
    printf("[2 : Generate Tokens]\n");
    printf("[3 : Parse The Code]\n");
    printf("[4 : Time Taken]\n");
    printf("------------------------------------------------------------\n\nChoice : ");
}

void printStatus()
{
    printf("\n\"However, for practical purposes, in a hopelessly practical world...\"\n");

    printf("\n==============================================================\n");
    printf("\u2022 FIRST and FOLLOW set automated \u2713\n");
    printf("\u2022 Both lexical and syntax analysis modules implemented \u2713\n");
    printf("\u2022 Modules work with testcases 2,3,4,5 \u2713\n");
    printf("\u2022 Parse tree constructed \u2713\n");
    printf("==============================================================\n");
}

int main(int argc, char *argv[])
{
    // int buffer_size = 0;

    /*
        Fun Trivia/Stats:
    -  We spent 4 hours debugging the Follow Set function
    -  We spent 4 hours designing and debugging the Error recovery strategies
    -  We spent close to 22 hours debugging the Parser
    -  Lines of Code: 4,600+ (excluding useless comments)
    -  Time spent combinedly (times when all 5 of us were together): 52hrs 45mins (approx.)
    -  Time spent per day: 52.75/28 = 1hr 53mins (approx.) (2 Feb - 1 Mar)
    -  It doesn't include the time spent individually by each of us
    */

    /*
    -  What you see below is the result of countless sleepless hours and a lot of hard work.
    -  Dealing other courses, assignments, quizzes and all, we still managed to get this done.
    -  When one of our teammates was down with a fever; the other was unwell; and the third was overburdened with other courses,
        and yet we all sat down and went through this
    -  We did all we could; in our own ways; to get this done.
    */
    char *test_file_name = argv[1];
    char *tree_out_name = argv[2];
    BUFFER_SIZE = atoi(argv[3]);

    buffer_1 = (char *)malloc((BUFFER_SIZE + 1) * sizeof(char));
    buffer_2 = (char *)malloc((BUFFER_SIZE + 1) * sizeof(char));
    selected_buffer = (char *)malloc((BUFFER_SIZE + 1) * sizeof(char));

    buffer_1[BUFFER_SIZE] = '\0';
    buffer_2[BUFFER_SIZE] = '\0';
    selected_buffer[BUFFER_SIZE] = '\0';

    printStatus();

    int choice;
    printMenu();

    scanf("%d", &choice);
    printf("\n");

    clock_t start_time, end_time;

    double CPU_time = 0.0, CPU_time_sec = 0.0;

    while (choice != 0)
    {
        switch (choice)
        {
        case 1:
            removeComments(test_file_name, "non_comment.txt");
            break;
        case 2:
            callLexer(test_file_name);
            break;
        case 3:
            start_time = clock();
            callParser(test_file_name, tree_out_name);
            end_time = clock();
            CPU_time = (double)(end_time - start_time);
            CPU_time_sec = CPU_time / CLOCKS_PER_SEC;
            break;
        case 4:
            printf("[Time taken (CPU): %lf \u03BCs]\n", CPU_time);
            printf("[Time taken (in sec): %lf s]\n", CPU_time_sec);
            break;
        default:
            printf("[Invalid Choice]\n");
            break;
        }
        printMenu();
        scanf("%d", &choice);

        printf("\n");
    }
    printf("[Exiting...]\n");
}